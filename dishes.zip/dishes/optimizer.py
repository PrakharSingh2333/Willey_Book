import gurobipy as gp
from gurobipy import GRB

class optimizer_flow:
    def __init__(self,params):
        
        self.restaurant = gp.Model("Restaurant")
        self.dishes = params['dishes']
        self.hours = params['hours']
        self.input_requirement = params['input_requirement']
        self.input_cost = params['input_cost']
        self.prev_hours =params['prev_hours']
    
    def build_model(self):
        self.variable()
        self.demand_constraint()
        self.inventory_balance_constraint()
        self.objective()
    
    def variable(self):
        # it tells us about the prepare dish is multiple of 10
        self.dummy_prepare = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name  = 'prepare')
        
        # it tells about the amount of dish prepared at a start of hour h 
        self.prepare = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name  = 'prepare')
        
        # it tells about the amount of dish stored in inventory at a start of hour h
        self.inventory = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name = 'inventory')
        
        # it tells about the amount of dish sold between  hour h and h+1 
        self.sold = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name = 'sold')
        
        # it tells about the amount of dish wasted at start of hour h
        self.wasted_dish = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name = 'wasted_dish')
        
        # it tells about the amount of dish unfullfilled requirement at start of hour h
        self.unfullfilled_requirement = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name = 'unfullfilled_requirement')
        
        self.z = self.restaurant.addVars(self.dishes,self.hours,vtype = GRB.INTEGER,name = 'z')
    
    def demand_constraint(self):
        
        # amount of dishes sold should be equal to requirement and the unfullfilled requirement 
        self.restaurant.addConstrs((self.sold[i,h] == self.input_requirement.loc[i][h] - self.unfullfilled_requirement[i,h] 
                                    for i in self.dishes for h in self.hours))
        
        
        # amount of dishes sold in particular hour should be less than dishes prepared in that particular hour and inventory of that particular dish in that hour 
        self.restaurant.addConstrs((self.sold[i,h] <= self.prepare[i,h]+ self.inventory[i,h] for i in self.dishes
                                    for h in self.hours), name  = "Sold_constraint")
        
        
        # amount of dishes prepared should be multiple of 10 
        self.restaurant.addConstrs((self.prepare[i,h]== self.dummy_prepare[i,h]*10 for i in self.dishes for h in self.hours),name  = "prepare_constraint")
        
        
        # amount of unfullfill demand would be amount left after what is required and how much is prepared at particular hour
        # self.restaurant.addConstrs((self.unfullfilled_requirement[i,h] == self.input_requirement[i,h]-self.prepare[i,h] for i in self.dishes for h in self.hours))
    def inventory_balance_constraint(self):
        
        # inventory balance constraint for the first 5TH hour of the day 
          self.restaurant.addConstrs((self.inventory[i,5] == 0 
                                      for i in self.dishes),name  = "inventory_balance_intial")
          
          
        #inventory balance for the rest remaining hours of the day
          self.restaurant.addConstrs((self.inventory[i,h] == self.inventory[i,h-1]+self.prepare[i,h-1]-self.sold[i,h-1]-self.wasted_dish[i,h-1] 
                                    for i in self.dishes for h in self.prev_hours), name  = "inventory_balance")
          
          
        # wastage of dishes in particular hour should be less than inventory of that particular dish in that hour
        #   self.restaurant.addConstrs(self.wasted_dish[i,h ] ==gp.max_(
        #                                                               self.inventory[i,max(h-self.input_cost.loc[i]['shelf_life(hr)'],5)]- 
        #                     gp.quicksum(self.sold[i,h1] for h1 in range(max(h-self.input_cost.loc[i]['shelf_life(hr)']
        # ,5),h) ),constant=0) for i in self.dishes for h in self.hours)
          for i in self.dishes:
            for h in self.hours:
        # Calculate the starting point of the sum range
                start_h = int(max(h - self.input_cost.loc[i]['shelf_life(hr)'], 5))
            
            # Calculate the sum for the sold dishes
                sum_sold = gp.quicksum(self.sold[i, h1] for h1 in range(start_h, h))
            
            # Calculate the inventory value
                inventory_value = self.inventory[i, start_h]
            
            # Calculate the wasted dish constraint
            #     self.restaurant.addConstr(
            #     #  self.wasted_dish[i, h] == gp.max_(self.wasted_dish[i,max(h-1,5)], constant =0)
            #      self.wasted_dish[i, h] == inventory_value - sum_sold
            # )
                self.restaurant.addConstr(self.z[i,h]>=0)
                self.restaurant.addConstr(self.z[i,h]>=inventory_value - sum_sold)
                self.restaurant.addConstr(self.z[i,h]== self.wasted_dish[i,h])
                
        
    
          
          
    
    def objective(self):
        
        self.restaurant.setObjective(gp.quicksum(self.sold[i,h]*self.input_cost.loc[i]['Profit(₹)']
       -self.wasted_dish[i,h]*self.input_cost.loc[i]['Loss_on_wastage₹']-self.unfullfilled_requirement[i,h]
       *self.input_cost.loc[i]['Loss_on_demand(₹)'] for i in self.dishes for h in self.hours),GRB.MAXIMIZE)
        
        self.restaurant.optimize()
        