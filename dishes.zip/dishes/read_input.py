import pandas as pd
import os
curr_path = os.getcwd()
def read_data():
    params = {}
    input_cost = pd.read_excel(curr_path+"/Book1.xlsx",sheet_name="Sheet1")
    input_requirement = pd.read_excel(curr_path+"/Book1.xlsx",sheet_name="Sheet2")
    input_cost.set_index('Dishes',inplace=True)
    input_requirement.set_index('Dishes',inplace=True)
    params['input_cost'] = input_cost
    params['input_requirement'] = input_requirement
    params['dishes'] = input_cost.index.to_list()
    params['hours'] = input_requirement.columns.to_list()
    params['prev_hours'] = input_requirement.columns.to_list()[1:]
    
    return params

    
